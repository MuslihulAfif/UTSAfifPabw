<?php
include "database.php";
$query = "UPDATE tmhs SET nim='$_POST[nim]',nama='$_POST[nama]', alamat='$_POST[alamat], prodi='$_POST[prodi]' WHERE id_mhs='$_POST[id_mhs]'";
$data = $db->prepare($query);
$data->execute();
header("location:form.php");
?>